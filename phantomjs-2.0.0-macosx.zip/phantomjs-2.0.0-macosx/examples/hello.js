console.log('Hello, world!');
phantom.exit();
